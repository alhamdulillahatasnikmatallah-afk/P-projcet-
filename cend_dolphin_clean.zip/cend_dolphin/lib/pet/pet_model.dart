import 'dart:convert';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';

enum PetKind { dolphin, cat, dog, rabbit, fox, dragon }

extension PetKindX on PetKind {
  String get id => toString().split('.').last;

  String get label => switch (this) {
        PetKind.dolphin => 'Dolphin',
        PetKind.cat => 'Kucing',
        PetKind.dog => 'Anjing',
        PetKind.rabbit => 'Kelinci',
        PetKind.fox => 'Rubah',
        PetKind.dragon => 'Naga',
      };

  String get favorite => switch (this) {
        PetKind.dolphin => 'Ikan',
        PetKind.cat => 'Ikan',
        PetKind.dog => 'Daging',
        PetKind.rabbit => 'Wortel',
        PetKind.fox => 'Anggur',
        PetKind.dragon => 'Apel',
      };

  String get dislike => switch (this) {
        PetKind.dolphin => 'Wortel',
        PetKind.cat => 'Wortel',
        PetKind.dog => 'Wortel',
        PetKind.rabbit => 'Daging',
        PetKind.fox => 'Semangka',
        PetKind.dragon => 'Stroberi',
      };

  String greet() => switch (this) {
        PetKind.dolphin => 'Klik klik! Halo!',
        PetKind.cat => 'Meong. Kamu lagi.',
        PetKind.dog => 'Guk! Kamu pulang!',
        PetKind.rabbit => 'Kamu datang!',
        PetKind.fox => 'Hai, aku senang!',
        PetKind.dragon => 'Graaw... halo!',
      };
}

enum Background { pantai, rumah, hujan, taman, hutan, luarAngkasa }

extension BackgroundX on Background {
  String get id => toString().split('.').last;
  String get label => switch (this) {
        Background.pantai => 'Pantai',
        Background.rumah => 'Rumah',
        Background.hujan => 'Hujan',
        Background.taman => 'Taman Bunga',
        Background.hutan => 'Hutan',
        Background.luarAngkasa => 'Luar Angkasa',
      };
}

class PetState {
  PetKind kind;
  String name;
  Background background;
  int level;
  double xp;
  double hunger;
  double happy;
  double energy;
  DateTime lastSeen;
  int streak;
  String lastStreakDay;
  bool sadUntilGreeted;
  DateTime? sulkUntil;
  List<String> achievements;
  Map<String, int> stats;

  PetState({
    required this.kind,
    required this.name,
    this.background = Background.rumah,
    this.level = 1,
    this.xp = 0,
    this.hunger = 80,
    this.happy = 80,
    this.energy = 80,
    DateTime? lastSeen,
    this.streak = 0,
    this.lastStreakDay = '',
    this.sadUntilGreeted = false,
    this.sulkUntil,
    List<String>? achievements,
    Map<String, int>? stats,
  })  : lastSeen = lastSeen ?? DateTime.now(),
        achievements = achievements ?? [],
        stats = stats ?? {'pats': 0, 'feeds': 0, 'shakes': 0, 'toolsUsed': 0};

  double xpNeeded() => (50 * pow(level, 1.5)).roundToDouble();

  bool get isSulking => sulkUntil != null && DateTime.now().isBefore(sulkUntil!);

  void addXp(double amount) {
    xp += amount;
    while (xp >= xpNeeded()) {
      xp -= xpNeeded();
      level += 1;
    }
  }

  void applyDecay() {
    final now = DateTime.now();
    final diff = now.difference(lastSeen);
    if (diff.isNegative) {
      lastSeen = now;
      return;
    }
    final hours = diff.inMinutes / 60.0;
    hunger = max(15, hunger - 4 * hours);
    happy = max(15, happy - 2 * hours);
    if (hours > 12 && !sadUntilGreeted) {
      sadUntilGreeted = true;
    }
    lastSeen = now;
  }

  void greetBack() {
    if (sadUntilGreeted) {
      sadUntilGreeted = false;
      addXp(10);
      happy = min(100, happy + 15);
    }
  }

  void bumpStreak() {
    final today =
        '${DateTime.now().year}-${DateTime.now().month}-${DateTime.now().day}';
    if (lastStreakDay == today) return;
    final yesterday = DateTime.now().subtract(const Duration(days: 1));
    final yStr = '${yesterday.year}-${yesterday.month}-${yesterday.day}';
    if (lastStreakDay == yStr) {
      streak += 1;
    } else {
      streak = 1;
    }
    lastStreakDay = today;
    if ([3, 7, 14, 30].contains(streak)) {
      addXp(20);
    }
  }

  Map<String, dynamic> toJson() => {
        'kind': kind.id,
        'name': name,
        'background': background.id,
        'level': level,
        'xp': xp,
        'hunger': hunger,
        'happy': happy,
        'energy': energy,
        'lastSeen': lastSeen.toIso8601String(),
        'streak': streak,
        'lastStreakDay': lastStreakDay,
        'sadUntilGreeted': sadUntilGreeted,
        'achievements': achievements,
        'stats': stats,
      };

  static PetState fromJson(Map<String, dynamic> j, PetKind kind) {
    try {
      return PetState(
        kind: kind,
        name: (j['name'] ?? kind.label).toString(),
        background: Background.values.firstWhere(
            (b) => b.id == j['background'],
            orElse: () => Background.rumah),
        level: (j['level'] ?? 1) as int,
        xp: (j['xp'] ?? 0).toDouble(),
        hunger: (j['hunger'] ?? 80).toDouble(),
        happy: (j['happy'] ?? 80).toDouble(),
        energy: (j['energy'] ?? 80).toDouble(),
        lastSeen: DateTime.tryParse(j['lastSeen'] ?? '') ?? DateTime.now(),
        streak: (j['streak'] ?? 0) as int,
        lastStreakDay: (j['lastStreakDay'] ?? '').toString(),
        sadUntilGreeted: (j['sadUntilGreeted'] ?? false) as bool,
        achievements: List<String>.from(j['achievements'] ?? []),
        stats: Map<String, int>.from(j['stats'] ?? {}),
      );
    } catch (_) {
      return PetState(kind: kind, name: kind.label);
    }
  }
}

class PetStore {
  static Future<void> save(PetState s) async {
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString('pet_${s.kind.id}', jsonEncode(s.toJson()));
      await sp.setString('active_pet', s.kind.id);
    } catch (_) {}
  }

  static Future<PetState?> loadActive() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final id = sp.getString('active_pet');
      if (id == null) return null;
      final kind = PetKind.values.firstWhere((k) => k.id == id,
          orElse: () => PetKind.dolphin);
      final raw = sp.getString('pet_$id');
      if (raw == null) return null;
      return PetState.fromJson(jsonDecode(raw), kind);
    } catch (_) {
      return null;
    }
  }

  static Future<PetState> loadOrCreate(PetKind kind, String name) async {
    try {
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString('pet_${kind.id}');
      if (raw != null) {
        final s = PetState.fromJson(jsonDecode(raw), kind);
        await sp.setString('active_pet', kind.id);
        return s;
      }
    } catch (_) {}
    final s = PetState(kind: kind, name: name);
    await save(s);
    return s;
  }
}
