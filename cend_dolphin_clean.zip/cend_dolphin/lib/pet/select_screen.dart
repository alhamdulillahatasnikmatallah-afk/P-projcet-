import 'package:flutter/material.dart';
import 'package:cend_dolphin/core/theme.dart';
import 'package:cend_dolphin/core/sound.dart';
import 'package:cend_dolphin/pet/pet_model.dart';
import 'package:cend_dolphin/pet/pet_sprites.dart';
import 'package:cend_dolphin/pet/pixel_painter.dart';
import 'package:cend_dolphin/pet/pet_screen.dart';

class SelectPetScreen extends StatefulWidget {
  const SelectPetScreen({super.key});
  @override
  State<SelectPetScreen> createState() => _SelectPetScreenState();
}

class _SelectPetScreenState extends State<SelectPetScreen> {
  PetKind kind = PetKind.dolphin;
  final nameCtrl = TextEditingController();

  Future<void> _start() async {
    Sfx.i.click();
    final name = nameCtrl.text.trim().isEmpty ? kind.label : nameCtrl.text.trim();
    final safe = name.length > 12 ? name.substring(0, 12) : name;
    final s = await PetStore.loadOrCreate(kind, safe);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => PetScreen(state: s)));
  }

  @override
  Widget build(BuildContext context) {
    final pal = paletteFor(kind);
    return Scaffold(
      backgroundColor: PastelPalette.cream,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            const SizedBox(height: 12),
            Text('Pilih temanmu', style: roundedText(22, PastelPalette.brown, w: FontWeight.w700)),
            const SizedBox(height: 20),
            PixelSprite(rows: spriteFor(kind, Expr.normal), palette: paletteToMap(pal), size: 150),
            const SizedBox(height: 16),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              alignment: WrapAlignment.center,
              children: PetKind.values
                  .map((k) => _kindChip(k))
                  .toList(),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: nameCtrl,
              maxLength: 12,
              style: roundedText(14, PastelPalette.brown),
              decoration: InputDecoration(
                hintText: 'Beri nama (maks 12 huruf)',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _start,
                style: ElevatedButton.styleFrom(
                  backgroundColor: PastelPalette.orange,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: Text('MULAI', style: roundedText(14, Colors.white, w: FontWeight.w700)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _kindChip(PetKind k) {
    final selected = k == kind;
    return GestureDetector(
      onTap: () {
        Sfx.i.click();
        setState(() => kind = k);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? PastelPalette.orange : Colors.white,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(k.label,
            style: roundedText(12, selected ? Colors.white : PastelPalette.brown)),
      ),
    );
  }
}

Map<String, Color> paletteToMap(PetPalette p) => {
      'K': p.outline,
      'B': p.body,
      'D': p.bodyDark,
      'A': p.accent,
      'C': p.cheek,
      'E': const Color(0xFF3A2E28),
      'M': const Color(0xFF3A2E28),
      '.': Colors.transparent,
    };
