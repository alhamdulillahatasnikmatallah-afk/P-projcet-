import 'dart:async';
import 'dart:convert';
import 'package:android_intent_plus/android_intent.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pty/flutter_pty.dart';
import 'package:xterm/xterm.dart';
import 'package:xterm/flutter.dart';

/// Interactive PTY backed by Android's actual /system/bin/sh.
/// Android's stock shell is not GNU Bash; the Termux button opens a real Bash
/// environment when Termux is installed.
class LinuxShellScreen extends StatefulWidget {
  const LinuxShellScreen({super.key});
  @override
  State<LinuxShellScreen> createState() => _LinuxShellScreenState();
}

class _LinuxShellScreenState extends State<LinuxShellScreen> {
  final Terminal terminal = Terminal(maxLines: 5000);
  Pty? pty;
  StreamSubscription<String>? outputSubscription;
  String status = 'Starting Android shell…';

  @override
  void initState() {
    super.initState();
    terminal.write('C PROJECT // NETWORK & SECURITY LAB\r\n');
    terminal.write('Starting a real Android PTY shell.\r\n');
    terminal.write('Note: /system/bin/sh is Android sh, not GNU Bash.\r\n\r\n');
    _startShell();
  }

  void _startShell() {
    try {
      final process = Pty.start('/system/bin/sh', columns: 80, rows: 24);
      pty = process;
      outputSubscription = process.output.cast<List<int>>().transform(const Utf8Decoder()).listen(terminal.write);
      terminal.onOutput = (data) => process.write(const Utf8Encoder().convert(data));
      terminal.onResize = (width, height, pixelWidth, pixelHeight) {
        process.resize(height, width);
      };
      process.exitCode.then((code) {
        if (mounted) setState(() => status = 'Shell exited (code $code)');
      });
      setState(() => status = 'Android PTY shell aktif');
    } catch (e) {
      terminal.write('Unable to start shell: $e\r\n');
      terminal.write('Use Termux for a full Bash/Linux userspace.\r\n');
      setState(() => status = 'Shell gagal dimulai');
    }
  }

  Future<void> _openTermux() async {
    try {
      const intent = AndroidIntent(
        action: 'android.intent.action.MAIN',
        category: 'android.intent.category.LAUNCHER',
        package: 'com.termux',
      );
      await intent.launch();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Termux belum terpasang. Pasang Termux dari sumber resminya, lalu coba lagi.'),
      ));
    }
  }

  @override
  void dispose() {
    outputSubscription?.cancel();
    pty?.kill();
    terminal.onOutput = null;
    terminal.onResize = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF080C09);
    const green = Color(0xFF8CF5A5);
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: const Color(0xFF111813),
        foregroundColor: green,
        title: const Text('NETWORK & SECURITY LAB'),
        actions: [IconButton(tooltip: 'Open Termux', onPressed: _openTermux, icon: const Icon(Icons.open_in_new))],
      ),
      body: Column(children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          color: const Color(0xFF111813),
          child: Row(children: [
            const Icon(Icons.circle, color: green, size: 9),
            const SizedBox(width: 8),
            Expanded(child: Text(status, style: const TextStyle(color: green, fontSize: 12))),
            TextButton(onPressed: _openTermux, child: const Text('TERMUX BASH')),
          ]),
        ),
        Expanded(
          child: TerminalView(terminal, autofocus: true),
        ),
      ]),
    );
  }

}
