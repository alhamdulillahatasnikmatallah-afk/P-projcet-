import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cend_dolphin/core/theme.dart';
import 'package:cend_dolphin/core/sound.dart';

class TermScaffold extends StatelessWidget {
  final String title;
  final Widget child;
  const TermScaffold({super.key, required this.title, required this.child});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: TermPalette.bg,
        appBar: AppBar(
          backgroundColor: TermPalette.panel,
          iconTheme: const IconThemeData(color: TermPalette.accent),
          title: Text('> $title',
              style: GoogleFonts.robotoMono(
                  color: TermPalette.accent, fontWeight: FontWeight.bold)),
        ),
        body: Padding(padding: const EdgeInsets.all(14), child: child),
      );
}

class TermButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const TermButton({super.key, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () {
          Sfx.i.click();
          onTap();
        },
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: TermPalette.accent, borderRadius: BorderRadius.circular(4)),
          child: Center(
              child: Text(label,
                  style: termText(13, TermPalette.bg).copyWith(fontWeight: FontWeight.bold))),
        ),
      );
}

class TermField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final TextInputType? type;
  const TermField({super.key, required this.controller, required this.hint, this.type});
  @override
  Widget build(BuildContext context) => TextField(
        controller: controller,
        keyboardType: type,
        style: termText(13, TermPalette.text),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: termText(12, TermPalette.dim),
          filled: true,
          fillColor: TermPalette.panel,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(4), borderSide: BorderSide.none),
        ),
      );
}

class TermOutput extends StatelessWidget {
  final String text;
  const TermOutput({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
            color: TermPalette.panel, borderRadius: BorderRadius.circular(4)),
        child: SelectableText(text.isEmpty ? '...' : text,
            style: termText(12, TermPalette.text)),
      );
}

class TermListTile extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const TermListTile({super.key, required this.label, required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () {
          Sfx.i.click();
          onTap();
        },
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
              color: TermPalette.panel,
              border: Border.all(color: TermPalette.accent.withOpacity(0.3)),
              borderRadius: BorderRadius.circular(4)),
          child: Row(children: [
            Icon(icon, color: TermPalette.accent, size: 18),
            const SizedBox(width: 10),
            Expanded(child: Text('> $label', style: termText(13, TermPalette.text))),
            const Icon(Icons.chevron_right, color: TermPalette.dim, size: 18),
          ]),
        ),
      );
}
